# Driving_School_Management
This is the driving school management application in PHP as backend and HTML5 and CSS is used for frontend.
This is working and tested application and I have all necessary features like:
Login/Logout.
Forms Validations
Fomra data insert/fetch/delete.
Get Data/Reports in to excel.
Billing Module.
Cars Management.
Cool features, A complete Project for learning, understanding, school/college projects :)

If you have any doubt or query then reach to me.
